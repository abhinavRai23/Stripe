<?php # config.inc.php
// Created by Larry Ullman, www.larryullman.com, @LarryUllman
// Posted as part of the series "Processing Payments with Stripe"
// http://www.larryullman.com/series/processing-payments-with-stripe/
// Last updated April 14, 2015

// This page sets some global properties and defines one or more functions.
// This page is intended to be stored in a protected "includes" directory.

// Define useful constants:
define('STRIPE_PRIVATE_KEY', 'sk_test_lqltYY1yLSKPhfRIaXofcXfU');
define('STRIPE_PUBLIC_KEY', 'pk_test_gAib6Fjd1OzpPwMqIUnFuu8T');